#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(void){

printf(1, "Total number of System Calls until now: %d\n", readcount());
exit();
}
